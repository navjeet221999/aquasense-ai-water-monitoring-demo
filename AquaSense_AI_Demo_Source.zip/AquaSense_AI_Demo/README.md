# AquaSense AI Demo

AquaSense AI is a concept-stage demonstration for Frontier Buildathon 2026.

## What it demonstrates
- A responsive water-monitoring dashboard
- Simulated water-flow readings
- Three selectable scenarios: possible leak, normal usage, and sudden spike
- Rule-based anomaly flags
- Recent readings table, trend chart, alerts, and usage-by-time summary

## Important limitations
- This demo uses simulated data only.
- It is not connected to a real water-flow sensor.
- The alert logic is a simple demonstration rule, not a trained or validated machine-learning model.
- A flagged anomaly means “investigate this pattern,” not “a leak is confirmed.”
- Water-use and potential-loss values are illustrative, not validated measurements.

## Run locally
1. Download `index.html`.
2. Open it in a modern web browser.
3. Choose a scenario and click **Run simulation**.

No installation, server, API key, or external library is required.

## Suggested next development steps
1. Replace simulated data with readings from a flow sensor or a clearly documented dataset.
2. Add configurable baseline thresholds for each site.
3. Create labelled normal/leak test scenarios and report detection rate and false-alert rate.
4. Only after adequate data is available, compare a suitable anomaly-detection model.
5. Add timestamps, exportable reports, and optional sensor integration.

## Suggested GitHub repository name
`aquasense-ai-water-monitoring-demo`
